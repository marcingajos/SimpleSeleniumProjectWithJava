# Prerequisites 

1. Install Java IDE software e.g. [IntelliJ IDEA Community](https://www.jetbrains.com/idea/download) 
1. Install Java Development Kit e.g. [OpenJDK](https://www.openlogic.com/openjdk-downloads) 
1. Clone or download repository to your local machine
1. Open project in IDE by pointing to the project folder
1. Build project
1. Run tests directly from the test classes or from the terminal

Note: Tests will be executed with default parameters which can be set up in an application config file (resources\app.properties)

#API Documentation

[Selenium API](https://www.selenium.dev/selenium/docs/api/java/index.html?overview-summary.html)
[JUnit API](https://junit.org/junit5/docs/current/user-guide/)
[JAVA API](https://docs.oracle.com/javase/8/docs/api/)

