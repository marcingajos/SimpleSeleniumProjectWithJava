package Helpers;

import Utilities.GlobalParamsFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.NoSuchElementException;


public class SeleniumHelpers {
    WebDriver driver;
    public SeleniumHelpers(WebDriver driver) {
        this.driver = driver;
    }

    public void WaitUntilElementAppear(By locator)
    {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(GlobalParamsFactory.ExplicitWait));
            wait.until(x -> CheckIfElementPresent(locator));
            System.out.println("Element defined by locator: " + locator.toString() + " exists.");
        } catch (WebDriverException e)
        {
            //do smg here
            throw e;
        }
    }

    public boolean CheckIfElementPresent(By locator)
    {
        try
        {
            driver.findElement(locator);
        }
        catch (NoSuchElementException e)
        {
            return false;
        }
        return true;
    }

    public void ClickOnElement(By locator)
    {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(GlobalParamsFactory.ExplicitWait));
            wait.until(x -> CheckIfElementPresent(locator));

            driver.findElement(locator).click();
        } catch (WebDriverException e)
        {
            System.out.println("Element localized by locator = " + locator.toString() + " not found.");
            throw e;
        }

    }

    public void WaitForOptionalElement(By locator) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(GlobalParamsFactory.ExplicitWait));
            wait.until(x -> CheckIfElementPresent(locator));
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            System.out.println("Optional element localized by locator = " + locator.toString() + " not found.");

        }
    }
}

