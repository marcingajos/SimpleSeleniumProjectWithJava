package PageObjects.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import PageObjects.BasePage;

import static Utilities.GlobalParamsFactory.*;

public class HomePage extends BasePage
{
    private By BHLogo = By.cssSelector("app-bh-logo");
    public HomePage(WebDriver driver)
    {
        super(driver);
    }

    public void NavigateToSpecificURL() {
        driver.navigate().to(BaseUrl);
    }

    public void VerifyIfPageIsAvailable() {
        AcceptCookies();
        WaitUntilElementAppear(BHLogo);


    }
}
