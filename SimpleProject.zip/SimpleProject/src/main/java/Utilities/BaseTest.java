package Utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import PageObjects.Pages.*;
import PageObjects.SharedObjects.*;

public class BaseTest extends GlobalParamsFactory
{
    public HomePage homePage;
    public Header header;

    @BeforeAll
    static void setupChromedriver() {
        WebDriverManager.chromedriver().setup();
    }

    @BeforeEach
    public void setUp() throws Exception {
        ReadConfig();
        SetupBrowser();
        InitObjects();
    }

    @AfterEach
    public void tearDown() throws Exception {
      //  Driver.close();
      //  Driver.quit();
    }

    public void InitObjects()
    {
        header = new Header(driver);
        homePage = new HomePage(driver);
    }
}
