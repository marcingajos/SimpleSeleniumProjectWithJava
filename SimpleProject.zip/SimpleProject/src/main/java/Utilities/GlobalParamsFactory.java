package Utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import java.io.FileInputStream;
import java.util.Properties;

import static java.lang.Integer.parseInt;

public class GlobalParamsFactory {
    protected WebDriver driver;
    public static int ExplicitWait;
    public static int ImplicitWait;
    public static String BaseUrl;

    public void SetupBrowser()
    {
        this.driver = GetDriver();
        driver.manage().window().maximize();
    }

    public WebDriver GetDriver()
    {
        ChromeOptions chromeOptions = new ChromeOptions();
        WebDriverManager.chromedriver().setup();
        return new ChromeDriver(chromeOptions);
        //FirefoxOptions firefoxOptions = new FirefoxOptions();
        //WebDriverManager.firefoxdriver().setup();
        //WebDriver driver = new FirefoxDriver(firefoxOptions);
    }


    public void ReadConfig() throws Exception
    {
        FileInputStream configFile = new FileInputStream("src/main/resources/app.properties");
        Properties properties = new Properties();
        properties.load(configFile);
        BaseUrl = properties.getProperty("BaseUrl");
        ExplicitWait = parseInt(properties.getProperty("ExplicitWait"));
        ImplicitWait = parseInt(properties.getProperty("ImplicitWait"));

    }
}
