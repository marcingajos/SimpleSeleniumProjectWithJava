package Tests;

import org.junit.jupiter.api.Test;
import Utilities.BaseTest;

public class SmokeTest extends BaseTest
{
    @Test
    public void VerifyIfPageIsAvailable() throws InterruptedException {
        homePage.NavigateToSpecificURL();
        Thread.sleep(5000);
        homePage.VerifyIfPageIsAvailable();
    }
}
